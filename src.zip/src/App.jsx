import React from 'react';
import './App.css'
import Maincomponents from './components/main-components';
// import ImageList from './components/image';


function App() {

  return (
    < div >
    <Maincomponents/>
    {/* <ImageList/> */}
    </div>
  )
}

export default App
